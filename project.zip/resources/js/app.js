import './bootstrap';

import Alpine from 'alpinejs';
import '@phosphor-icons/web/regular';
import '@phosphor-icons/web/bold';
import '@phosphor-icons/web/fill';

window.Alpine = Alpine;

Alpine.start();
