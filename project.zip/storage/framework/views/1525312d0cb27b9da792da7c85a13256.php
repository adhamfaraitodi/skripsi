<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-2xl font-bold mb-4">Shopping Cart</h2>

            <?php if(count($cart) > 0): ?>
                <div class="space-y-4">
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between border p-4 rounded">
                            <div class="flex items-center space-x-4">
                                <img src="<?php echo e(Storage::url($details['image_path'])); ?>" class="w-20 h-20 object-cover rounded">
                                <div>
                                    <h3 class="font-bold"><?php echo e($details['name']); ?></h3>
                                    <p>Price: Rp <?php echo e(number_format($details['price'], 0, ',', '.')); ?></p>
                                    <div class="flex items-center space-x-2 mt-2">
                                        <button onclick="updateQuantity(<?php echo e($id); ?>, 'decrease')"
                                                class="px-3 py-1 bg-gray-200 rounded">
                                            <i class="ph ph-minus text-sm"></i>
                                        </button>
                                        <span id="quantity-<?php echo e($id); ?>" class="px-4">
                                            <?php echo e($details['quantity']); ?>

                                        </span>
                                        <button onclick="updateQuantity(<?php echo e($id); ?>, 'increase')"
                                                class="px-3 py-1 bg-gray-200 rounded">
                                            <i class="ph ph-plus text-sm"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-bold" id="subtotal-<?php echo e($id); ?>">
                                    Subtotal: Rp <?php echo e(number_format($details['price'] * $details['quantity'], 0, ',', '.')); ?>

                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="border-t pt-4">
                        <p class="text-xl font-bold" id="total-amount">Total: Rp <?php echo e(number_format($total, 0, ',', '.')); ?></p>

                        <div class="flex space-x-4 mt-4">
                            <a href="<?php echo e(route('user.dine-in')); ?>">
                                <button class="font-sans font-bold text-center py-3 px-6 rounded-lg bg-gray-200 text-gray-800">
                                    Back to Menu
                                </button>
                            </a>
                            <a href="<?php echo e(route('user.checkout')); ?>" class="font-sans font-bold text-center py-3 px-6 rounded-lg bg-blue-600 text-white">
                                Checkout Order
                            </a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <p>Your cart is empty</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function updateQuantity(menuId, action) {
            const quantityElement = document.getElementById(`quantity-${menuId}`);
            let quantity = parseInt(quantityElement.textContent);

            if (action === 'increase') {
                quantity++;
            } else if (action === 'decrease' && quantity > 1) {
                quantity--;
            }

            fetch("<?php echo e(route('user.update-cart')); ?>", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                },
                body: JSON.stringify({
                    menu_id: menuId,
                    quantity: quantity
                })
            }).then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        quantityElement.textContent = quantity;
                        document.getElementById(`subtotal-${menuId}`).textContent =
                            `Subtotal: Rp ${new Intl.NumberFormat('id-ID').format(data.subtotal)}`;
                        document.getElementById('total-amount').textContent =
                            `Total: Rp ${new Intl.NumberFormat('id-ID').format(data.total)}`;
                    }
                }).catch(error => console.error("Error:", error));
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\skripsi\project\resources\views/user/cart_user.blade.php ENDPATH**/ ?>