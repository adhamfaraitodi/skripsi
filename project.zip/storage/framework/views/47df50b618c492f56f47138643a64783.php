<div class="relative flex flex-col text-gray-700 bg-white shadow-md bg-clip-border rounded-xl w-full">
    <div class="relative mx-4 mt-4 overflow-hidden text-gray-700 bg-white bg-clip-border rounded-xl h-30 flex items-center justify-center">
        <?php echo e($content); ?>

    </div>

    <div class="p-6">
        <?php echo e($tittle); ?>

        <p class="block font-sans text-sm antialiased font-normal leading-normal text-gray-700 opacity-75 ">
            <?php echo e($description); ?>

        </p>
    </div>
    <div class="mt-auto pb-4">
        <?php echo e($button); ?>

    </div>
</div>
<?php /**PATH C:\Users\HP\Downloads\skripsi\project\resources\views/components/card.blade.php ENDPATH**/ ?>