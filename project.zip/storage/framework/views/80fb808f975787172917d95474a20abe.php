<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <div class="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-6 gap-5 justify-center">
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('content', null, []); ?> 
                        <div id="qrcode-<?php echo e($data->table_code); ?>"></div>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('tittle', null, []); ?> 
                        <div class="flex items-center justify-center mb-2">
                            <p class="block font-sans text-base antialiased font-medium leading-relaxed text-blue-gray-900">
                                Table Number <?php echo e($data->number); ?>

                            </p>
                        </div>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('description', null, []); ?> 
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('button', null, []); ?> 
                        <a href="<?php echo e(route('user.scan', ['id' => $data->table_code])); ?>">
                            <button
                                class="align-middle select-none font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-3 px-6 rounded-lg shadow-gray-900/10 hover:shadow-gray-900/20 focus:opacity-[0.85] active:opacity-[0.85] active:shadow-none block w-full bg-blue-gray-900/10 text-blue-gray-900 shadow-none hover:scale-105 hover:shadow-none focus:scale-105 focus:shadow-none active:scale-100"
                                type="button">
                                Select Table
                            </button>
                        </a>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            let tables = <?php echo json_encode($datas, 15, 512) ?>;
            tables.forEach(function (data) {
                let elementId = "qrcode-" + data.table_code;
                let url = "<?php echo e(url('/scan')); ?>/" + data.table_code;

                new QRCode(document.getElementById(elementId), {
                    text: url,
                    width: 100,
                    height: 100
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\project\resources\views/user/table_user.blade.php ENDPATH**/ ?>