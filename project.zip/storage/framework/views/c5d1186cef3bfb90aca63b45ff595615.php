<?php $__env->startSection('content'); ?>
    <div class="max-w-3xl mx-auto p-6 bg-white shadow-md rounded-lg">
        <h2 class="text-2xl font-bold mb-4">Checkout Order</h2>
        <div class="mb-4">
            <p class="text-lg font-semibold">Order ID: <?php echo e($order_id); ?></p>
            <p class="text-lg">Table: <?php echo e($table->number); ?></p>
        </div>
        <table class="w-full shadow-md rounded-lg overflow-hidden">
            <thead>
                <tr class="bg-gradient-to-r from-green-500 to-green-600 text-white">
                    <th class="px-4 py-3 text-left font-semibold tracking-wider">Image</th>
                    <th class="px-4 py-3 text-left font-semibold tracking-wider">Name</th>
                    <th class="px-4 py-3 text-center font-semibold tracking-wider">Quantity</th>
                    <th class="px-4 py-3 text-right font-semibold tracking-wider">Price</th>
                    <th class="px-4 py-3 text-right font-semibold tracking-wider">Subtotal</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php
                    $totalBeforeDiscount = 0;
                    $totalDiscount = 0;
                ?>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $totalBeforeDiscount += ($item['price'] * $item['quantity']);
                        $totalDiscount += ($item['discount'] * $item['quantity']);
                    ?>
                    <tr class="hover:bg-gray-50 transition-colors duration-200">
                        <td class="px-4 py-3">
                            <img src="<?php echo e(Storage::url($item['image_path'])); ?>" 
                                alt="<?php echo e($item['name']); ?>" 
                                class="w-20 h-14 object-cover rounded-md shadow-sm">
                        </td>
                        <td class="px-4 py-3 font-medium text-gray-900"><?php echo e($item['name']); ?></td>
                        <td class="px-4 py-3 text-center text-gray-600"><?php echo e($item['quantity']); ?></td>
                        <td class="px-4 py-3 text-right text-gray-700">Rp<?php echo e(number_format($item['price'], 0, ',', '.')); ?></td>
                        <td class="px-4 py-3 text-right font-semibold text-gray-900">Rp<?php echo e(number_format($item['subtotal'], 0, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

            <?php
                $grossAmount = $totalBeforeDiscount - $totalDiscount;
            ?>

            <tfoot class="bg-gray-100">
                <tr>
                    <td colspan="4" class="px-4 py-3 text-right font-medium text-gray-700">Total Price:</td>
                    <td class="px-4 py-3 text-right font-semibold text-gray-900">Rp<?php echo e(number_format($totalBeforeDiscount, 0, ',', '.')); ?></td>
                </tr>
                <tr>
                    <td colspan="4" class="px-4 py-3 text-right font-medium text-gray-700">Total Discount:</td>
                    <td class="px-4 py-3 text-right font-semibold text-red-600">- Rp<?php echo e(number_format($totalDiscount, 0, ',', '.')); ?></td>
                </tr>
                <tr class="bg-green-50">
                    <td colspan="4" class="px-4 py-3 text-right font-bold text-green-800 text-lg">Grand Total:</td>
                    <td class="px-4 py-3 text-right font-bold text-green-800 text-xl">Rp<?php echo e(number_format($grossAmount, 0, ',', '.')); ?></td>
                </tr>
            </tfoot>
        </table>

        <div class="mb-4 mt-5">
            <label for="order_note" class="block text-lg font-semibold">Order Note:</label>
            <textarea id="order_note" name="order_note" class="w-full p-2 border border-gray-300 rounded" rows="3" placeholder="Add any special instructions here..."></textarea>
        </div>

        <button id="pay-button" 
                class="w-full bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 transition-colors">
            Confirm Order
        </button>
    </div>
    <script type="text/javascript"
        src="https://app.sandbox.midtrans.com/snap/snap.js"
        data-client-key="<?php echo e(config('services.midtrans.client_key')); ?>"></script>

        <script type="text/javascript">
        document.getElementById('pay-button').addEventListener('click', function () {
            // Disable button to prevent multiple clicks
            const button = this;
            button.disabled = true;
            button.textContent = "Processing...";

            // First, create the order with the note
            fetch("<?php echo e(route('user.checkout.create')); ?>", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                },
                body: JSON.stringify({ 
                    order_note: document.getElementById('order_note').value 
                })
            })
            .then(response => response.json())
            .then(data => {
                
                if (data.snap_token) {
                    
                    window.snap.pay(data.snap_token, {
                        onSuccess: function(result) {
                            alert("Payment Successful!");
                            console.log(result);
                            window.location.href = "<?php echo e(route('order.success')); ?>";
                        },
                        onPending: function(result) {
                            alert("Waiting for your payment...");
                            console.log(result);
                    
                        },
                        onError: function(result) {
                            alert("Payment Failed!");
                            console.log(result);
                            button.disabled = false;
                            button.textContent = "Confirm Order";
                        },
                        onClose: function() {
                            alert("You closed the payment popup.");
                            button.disabled = false;
                            button.textContent = "Confirm Order";
                        }
                    });
                } else {
                    alert(data.message || "Unable to process payment. Please try again.");
                    button.disabled = false;
                    button.textContent = "Confirm Order";
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Something went wrong. Please try again.');
                button.disabled = false;
                button.textContent = "Confirm Order";
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\project\resources\views/user/checkout_user.blade.php ENDPATH**/ ?>