<?php $__env->startSection('page_title', 'Sales Report'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4">
        <div class="bg-white shadow-md rounded-lg p-6">
            <div class="mt-6 flex justify-between items-center print:hidden">
                <div class="space-x-2">
                    <button onclick="printSection();" class="px-4 py-2 bg-blue-500 text-white rounded-lg shadow hover:bg-blue-600">
                        <i class="ph ph-printer mr-2"></i> Print
                    </button>
                </div>
            </div>
            <div id="printable-content">
                <div class="flex items-center justify-center border-b border-gray-400 pb-5 mb-6">
                    <img src="<?php echo e(asset('storage/icon/icon.png')); ?>" alt="Logo" class="w-10 mr-4">
                    <div class="text-center">
                        <h2 class="text-xl font-bold pr-11 mt-2 uppercase">YOSHIMIE</h2>
                        <p class="text-sm text-gray-700">Jl. Kaliurang KM 11, Pedak, Sinduharjo, Kec. Ngaglik, Yogyakarta 55581</p>
                        <p class="text-sm text-gray-700">Phone: 081250514071 | Email: bakmiehotplate@gmail.com</p>
                    </div>
                </div>

                <div class="text-center mb-6">
                    <h1 class="text-1xl font-semibold uppercase">Laporan Penjualan Bulanan</h1>
                    <p class="text-lg text-gray-600">Bulan: <?php echo e(Carbon\Carbon::now()->format('F Y')); ?></p>
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white border border-gray-300">
                        <thead class="bg-gray-200">
                        <tr class="border-b">
                            <th class="py-2 px-4 text-left">No</th>
                            <th class="py-2 px-4 text-left">Tanggal</th>
                            <th class="py-2 px-4 text-left">Nama Menu</th>
                            <th class="py-2 px-4 text-left">Qty</th>
                            <th class="py-2 px-4 text-right">Harga satuan</th>
                            <th class="py-2 px-4 text-right">Discount</th>
                            <th class="py-2 px-4 text-right">Subtotal</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-b">
                                <td class="py-2 px-4"><?php echo e($index + 1); ?></td>
                                <td class="py-2 px-4"><?php echo e(Carbon\Carbon::parse($item->created_at)->format('d/m/Y H:i')); ?></td>
                                <td class="py-2 px-4"><?php echo e($item->name); ?></td>
                                <td class="py-2 px-4"><?php echo e($item->quantity); ?></td>
                                <td class="py-2 px-4 text-right">Rp <?php echo e(number_format($item->price_food, 0, ',', '.')); ?></td>
                                <td class="py-2 px-4 text-right">Rp <?php echo e(number_format($item->discount, 0, ',', '.')); ?></td>
                                <td class="py-2 px-4 text-right">Rp <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="py-4 text-center text-gray-600">Tidak ada data penjualan untuk bulan ini</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                        <tfoot class="bg-gray-100">
                        <tr class="border-t">
                            <td colspan="5"></td>
                            <td class="py-2 px-4 text-right font-semibold">Total:</td>
                            <td class="py-2 px-4 text-right font-semibold">Rp <?php echo e(number_format($total, 0, ',', '.')); ?></td>
                        </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="text-right mt-6 text-sm text-gray-500">
                    <p><strong>Dicetak Pada:</strong> <?php echo e(now()->format('d/m/Y H:i:s')); ?></p>
                </div>
            </div>
        </div>
    </div>

    <script>
        function printSection() {
            let printContent = document.getElementById('printable-content').innerHTML;
            let originalContent = document.body.innerHTML;

            document.body.innerHTML = printContent;
            window.print();
            document.body.innerHTML = originalContent;
            location.reload();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\skripsi\project\resources\views/admin/sales_report.blade.php ENDPATH**/ ?>