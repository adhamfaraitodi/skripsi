<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <div class="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-5 gap-5 justify-center">
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('content', null, []); ?> 
                        <img src="<?php echo e(Storage::url($data->image_path)); ?>" class="w-full h-full object-cover">
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('tittle', null, []); ?> 
                        <div class="flex items-center justify-between mb-2">
                            <p class="block font-sans text-base antialiased font-medium leading-relaxed text-blue-gray-900">
                                <?php echo e($data->name); ?>

                            </p>
                            <?php
                                $discountedPrice = $data->price - $data->discount;
                            ?>
                            <p class="block font-sans text-base antialiased font-medium leading-relaxed text-blue-gray-900">
                                <?php if($data->discount > 0): ?>
                                    <span class="text-red-600 line-through block text-sm">Rp <?php echo e(number_format($data->price, 0, ',', '.')); ?></span>
                                    <span class="text-black font-bold block">Rp <?php echo e(number_format($discountedPrice, 0, ',', '.')); ?></span>
                                <?php else: ?>
                                    <span class="text-black font-bold block">Rp <?php echo e(number_format($discountedPrice, 0, ',', '.')); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('description', null, []); ?> 
                        <?php echo e($data->description); ?>

                        <br>
                        <span class="font-medium">Stock:</span> 
                        <?php echo e($data->stock === null ? 'N/A' : $data->stock); ?><br>
                        <span class="font-medium">Category:</span> <?php echo e($data->category->name); ?>

                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('button', null, []); ?> 
                        <div class="flex justify-center items-center space-x-3">
                            <span class="text-black"><?php echo e($data->favorite); ?></span>
                            <button class="font-sans font-bold py-3 pr-10"
                                    type="button"
                                    onclick="toggleStar(this, '<?php echo e($data->id); ?>')">
                                <i class="bi <?php echo e($data->favorite > 0 ? 'bi-star-fill' : 'bi-star'); ?> text-yellow-500 text-xl"></i>
                            </button>
                            <?php if($data->stock === null): ?>
                                <button class="font-sans font-bold text-center py-3 px-6 rounded-lg bg-gray-500 text-white cursor-not-allowed"
                                        type="button"
                                        disabled>
                                    Not Available
                                </button>
                            <?php elseif($data->stock == 0): ?>
                                <button class="font-sans font-bold text-center py-3 px-6 rounded-lg bg-red-500 text-white cursor-not-allowed"
                                        type="button"
                                        disabled>
                                    Sold Out
                                </button>
                            <?php else: ?>
                            <button class="font-sans font-bold text-center py-3 px-6 rounded-lg bg-blue-500 text-white"
                                    type="button"
                                    onclick="addToCart(event, '<?php echo e($data->id); ?>')">
                                Add to Cart
                            </button>
                            <?php endif; ?>
                        </div>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
    function toggleStar(button, menuId) {
        let starIcon = button.querySelector("i");
        let favoriteCountSpan = button.previousElementSibling;
        let isCurrentlyFavorited = starIcon.classList.contains("bi-star-fill");

        fetch("<?php echo e(route('user.favorite')); ?>", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
            },
            body: JSON.stringify({ 
                menu_id: menuId,
                is_favorite: isCurrentlyFavorited ? "false" : "true"
            })
        }).then(response => response.json())
        .then(data => {
            if (data.status === "added") {
                starIcon.classList.remove("bi-star");
                starIcon.classList.add("bi-star-fill");
            } else if (data.status === "removed") {
                starIcon.classList.remove("bi-star-fill");
                starIcon.classList.add("bi-star");
            }
            favoriteCountSpan.textContent = data.favorite_count;
        }).catch(error => console.error("Error:", error));
    }

    function addToCart(event, itemId) {
        event.preventDefault();

        fetch("<?php echo e(route('user.add-cart')); ?>", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
            },
            body: JSON.stringify({ id: itemId })
        }).then(response => response.json())
            .then(data => {
                alert(data.message);
            }).catch(error => console.error("Error:", error));
    }
</script>


<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\project\resources\views/user/menu_user.blade.php ENDPATH**/ ?>