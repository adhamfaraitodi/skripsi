<footer class="bg-white rounded-lg p-4 mt-6">
    <div class="text-center text-gray-600">
        <p>&copy; {{ date('Y') }} YOSHIMIE. All rights reserved.</p>
    </div>
</footer>
