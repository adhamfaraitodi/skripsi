<footer class="bg-white rounded-lg p-4 mt-6">
    <div class="text-center text-gray-600">
        <p>&copy; <?php echo e(date('Y')); ?> YOSHIMIE. All rights reserved.</p>
    </div>
</footer>
<?php /**PATH C:\Users\HP\Downloads\skripsi\project\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>