<?php $__env->startSection('page_title', 'New Order Management'); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <?php if (isset($component)) { $__componentOriginal69ce08111976df7a79cd416995514cd4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69ce08111976df7a79cd416995514cd4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-data','data' => ['name' => 'Trash Food Menu Items']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Trash Food Menu Items')]); ?>
             <?php $__env->slot('column', null, []); ?> 
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">status order</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">order code</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">gross amount</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">note</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">action</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">detail</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">payment detail</th>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('row', null, []); ?> 
                <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium
                                <?php echo e($data->order_status == 'paid' ? 'text-green-600' : 'text-red-600'); ?>">
                                <?php echo e(ucfirst($data->order_status)); ?>

                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 font-semibold"><?php echo e($data->order_code); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 font-semibold"><?php echo e($data->gross_amount); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 font-semibold"><?php echo e($data->note); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <form action="<?php echo e(route('order.update', $data->id)); ?>" method="POST" class="flex items-center" onsubmit="return confirm('Do you want to finish this order');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <button type="submit"
                                        class="ml-2 text-green-600
                                        <?php echo e($data->order_status === 'pending' ? 'text-red-600 hover:text-red-900 cursor-not-allowed' : 'text-green-600 hover:text-green-900'); ?>"
                                    <?php echo e($data->order_status === 'pending' ? 'disabled' : ''); ?>>Proccess
                                    <i class="ph ph-check text-lg"></i>
                                </button>
                            </form>
                        </td>

                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <button onclick="toggleDropdown('order-detail-<?php echo e($data->id); ?>')"
                                    class="text-blue-600 hover:text-blue-900 flex items-center transition-all duration-300">
                                <span>View Detail</span>
                                <i class="ph ph-caret-down ml-2"></i>
                            </button>
                            <div id="order-detail-<?php echo e($data->id); ?>" class="hidden mt-2 bg-gray-50 rounded-lg shadow-md p-4 transition-all duration-300">
                                <h4 class="text-gray-700 font-semibold mb-2">Order Detail</h4>

                                <?php $__currentLoopData = $data->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="px-4 py-2 bg-white rounded-md mb-2 shadow-sm border border-gray-200">
                                        <p class="text-sm text-gray-800 font-semibold">
                                            <?php echo e($menuOrder->created_at->format('Y-m-d H:i:s')); ?> -
                                            <?php echo e($menuOrder->quantity); ?> x <?php echo e($menuOrder->menu->name); ?>

                                        </p>
                                        <p class="text-sm text-gray-500 italic">Price: Rp <?php echo e(number_format($menuOrder->price, 2)); ?></p>
                                        <p class="text-sm text-gray-500 italic">Subtotal: Rp <?php echo e(number_format($menuOrder->subtotal, 2)); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <button onclick="toggleDropdown('payment-detail-<?php echo e($data->id); ?>')"
                                    class="text-blue-600 hover:text-blue-900 flex items-center transition-all duration-300">
                                <span>View Payment Detail</span>
                                <i class="ph ph-caret-down ml-2"></i>
                            </button>
                            <div id="payment-detail-<?php echo e($data->id); ?>" class="hidden mt-2 bg-gray-50 rounded-lg shadow-md p-4 transition-all duration-300">
                                <h4 class="text-gray-700 font-semibold mb-2">Order Detail</h4>
                                <div class="px-4 py-2 bg-white rounded-md mb-2 shadow-sm border border-gray-200">
                                    <p class="text-sm text-gray-800 font-semibold">
                                        <?php echo e($data->payment->created_at->format('Y-m-d H:i:s') ?? 'N/A'); ?> -
                                    </p>
                                    <p class="text-sm text-gray-500 italic">Status: <?php echo e($data->payment->transaction_status ?? 'N/A'); ?></p>
                                    <p class="text-sm text-gray-500 italic">Payment Type: <?php echo e($data->payment->payment_type ?? 'N/A'); ?></p>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('scripting', null, []); ?> 
                <script>
                    function toggleDropdown(id) {
                        document.getElementById(id).classList.toggle('hidden');
                    }
                </script>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $attributes = $__attributesOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__attributesOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $component = $__componentOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__componentOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\skripsi\project\resources\views/admin/order.blade.php ENDPATH**/ ?>