<?php $__env->startSection('page_title', 'Food Inventory Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <?php if (isset($component)) { $__componentOriginal69ce08111976df7a79cd416995514cd4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69ce08111976df7a79cd416995514cd4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-data','data' => ['name' => 'Food Stock Inventory']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Food Stock Inventory')]); ?>
             <?php $__env->slot('column', null, []); ?> 
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Menu Name</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Current Quantity</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Sold</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Add Quantity</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">History</th>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('row', null, []); ?> 
                <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo e($data->name); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 font-semibold"><?php echo e(optional($data->inventory->first())->current_quantity ?? 'N/A'); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 font-semibold"><?php echo e($sold[$data->id] ?? 0); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <form action="<?php echo e(route('inventory.update', $data->id)); ?>" method="POST" class="flex items-center">
                                <?php echo csrf_field(); ?>
                                <input type="number" name="quantity" min="1" required
                                       class="border rounded-md px-2 py-1 w-20 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <button type="submit" class="ml-2 text-green-600 hover:text-green-900">
                                    <i class="ph ph-plus text-lg"></i>
                                </button>
                            </form>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <button onclick="toggleDropdown('inventory-<?php echo e($data->id); ?>')" class="text-blue-600 hover:text-blue-900 flex items-center">
                                <span>View History</span>
                                <i class="ph ph-caret-down ml-2"></i>
                            </button>

                            <div id="inventory-<?php echo e($data->id); ?>" class="hidden mt-2 bg-gray-50 rounded-lg shadow-md p-4">
                                <h4 class="text-gray-700 font-semibold mb-2">Inventory History</h4>
                                <?php $__currentLoopData = $data->inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="px-4 py-2 bg-white rounded-md mb-2 shadow-sm">
                                        <p class="text-sm text-gray-800 font-semibold">
                                            <?php echo e($inventory->created_at->format('Y-m-d H:i:s')); ?> -
                                            <?php echo e($inventory->quantity); ?> (<?php echo e(ucfirst($inventory->transaction_type)); ?>)
                                        </p>
                                        <p class="text-sm text-gray-500 italic">Reason: <?php echo e($inventory->reason); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('scripting', null, []); ?> 
                <script>
                    function toggleDropdown(id) {
                        document.getElementById(id).classList.toggle('hidden');
                    }
                </script>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $attributes = $__attributesOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__attributesOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $component = $__componentOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__componentOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\skripsi\project\resources\views/admin/inventory.blade.php ENDPATH**/ ?>