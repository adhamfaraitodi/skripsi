<?php $__env->startSection('page_title', 'Food Menu Management'); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <?php if (isset($component)) { $__componentOriginald6d5a129e1c5e711793b7844f5994f6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald6d5a129e1c5e711793b7844f5994f6a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button.add','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button.add'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('route', null, []); ?> <?php echo e(route('food.create')); ?> <?php $__env->endSlot(); ?>
             <?php $__env->slot('massage', null, []); ?> Add New Food <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald6d5a129e1c5e711793b7844f5994f6a)): ?>
<?php $attributes = $__attributesOriginald6d5a129e1c5e711793b7844f5994f6a; ?>
<?php unset($__attributesOriginald6d5a129e1c5e711793b7844f5994f6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald6d5a129e1c5e711793b7844f5994f6a)): ?>
<?php $component = $__componentOriginald6d5a129e1c5e711793b7844f5994f6a; ?>
<?php unset($__componentOriginald6d5a129e1c5e711793b7844f5994f6a); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal69ce08111976df7a79cd416995514cd4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69ce08111976df7a79cd416995514cd4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-data','data' => ['name' => 'Table Management']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Table Management')]); ?>
         <?php $__env->slot('column', null, []); ?> 
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No.</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Photo</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Discount</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Favorites</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Visibility</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Added By</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('row', null, []); ?> 
            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900"><?php echo e($data->id); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center">
                            <div class="w-48 text-sm font-medium text-gray-900"><?php echo e($data->name); ?></div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="w-48 h-32 overflow-hidden">
                            <img src="<?php echo e(Storage::url($data->image_path)); ?>" class="w-full h-full object-cover">
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900"><?php echo e($data->category->name); ?></div>
                    </td>
                    <td class="px-6 py-4">
                        <div class="text-sm text-gray-900 max-w-xs truncate"><?php echo e($data->description); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900">Rp <?php echo e(number_format($data->price, 0, ',', '.')); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <?php if($data->discount > 0): ?>
                            <span class="px-2 inline-flex text-sm ">Rp <?php echo e(number_format($data->discount, 0, ',', '.')); ?></span>
                        <?php else: ?>
                            <span class="text-sm text-gray-500">Rp 0</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center">
                            <i class="bi bi-heart-fill text-red-500 mr-1"></i>
                            <span class="text-sm text-gray-900"><?php echo e($data->favorite); ?></span>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm <?php echo e($data->status == 1 ? 'text-green-600' : 'text-red-600'); ?>">
                            <?php echo e($data->status == 1 ? 'Show' : 'Hidden'); ?>

                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900"><?php echo e($data->user->name); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                        <div class="flex space-x-2">
                            <a href="<?php echo e(route('food.edit', $data->id)); ?>" class="text-blue-600 hover:text-blue-900 text-lg p-2">
                                <i class="ph ph-note-pencil"></i>
                            </a>
                            <form action="<?php echo e(route($data->status == 1 ? 'food.destroy' : 'food.restore', $data->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Do you want to change food menu visibility');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <button type="submit" class="text-lg p-2 <?php echo e($data->status == 1 ? 'text-red-600 hover:text-red-900' : 'text-green-600 hover:text-green-900'); ?>">
                                    <i class="ph <?php echo e($data->status == 1 ? 'ph-eye-closed' : 'ph-eye'); ?>"></i>
                                </button>
                            </form>
                            <form action="<?php echo e(route('food.remove', $data->id)); ?>" method="POST" onsubmit="return confirm('Do you want to delete this food?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-900 text-lg p-2">
                                    <i class="ph ph-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('scripting', null, []); ?>  <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $attributes = $__attributesOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__attributesOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $component = $__componentOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__componentOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\project\resources\views/admin/food.blade.php ENDPATH**/ ?>