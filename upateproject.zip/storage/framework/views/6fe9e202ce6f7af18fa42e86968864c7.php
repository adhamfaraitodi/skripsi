<?php $__env->startSection('page_title', 'History Order'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <?php if (isset($component)) { $__componentOriginal69ce08111976df7a79cd416995514cd4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69ce08111976df7a79cd416995514cd4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-data','data' => ['name' => 'History Order Table']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('History Order Table')]); ?>
             <?php $__env->slot('column', null, []); ?> 
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">status order</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">order code</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">gross amount</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">note</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">detail</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">payment detail</th>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('row', null, []); ?> 
                <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium
                                <?php echo e($data->order_status == 'success' ? 'text-green-600' : 'text-red-600'); ?>">
                                <?php echo e(ucfirst($data->order_status)); ?>

                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 font-semibold"><?php echo e($data->order_code); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 font-semibold"><?php echo e($data->gross_amount); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900 font-semibold"><?php echo e($data->note); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <?php if (isset($component)) { $__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pop-up','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pop-up'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                 <?php $__env->slot('id', null, []); ?> 
                                    order-detail-<?php echo e($data->id); ?>

                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('title', null, []); ?> 
                                    Order Detail
                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('content', null, []); ?> 
                                    <?php $__currentLoopData = $data->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="px-4 py-2 bg-white rounded-md mb-2 shadow-sm border border-gray-200">
                                        <p class="text-sm text-gray-800 font-semibold">
                                            <?php echo e($menuOrder->created_at->format('Y-m-d H:i:s')); ?> -
                                            <?php echo e($menuOrder->quantity); ?> x <?php echo e($menuOrder->menu->name); ?>

                                        </p>
                                        <p class="text-sm text-gray-500 italic">Price: Rp <?php echo e(number_format($menuOrder->price, 2)); ?></p>
                                        <p class="text-sm text-gray-500 italic">Subtotal: Rp <?php echo e(number_format($menuOrder->subtotal, 2)); ?></p>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d)): ?>
<?php $attributes = $__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d; ?>
<?php unset($__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d)): ?>
<?php $component = $__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d; ?>
<?php unset($__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d); ?>
<?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <?php if (isset($component)) { $__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pop-up','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pop-up'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                 <?php $__env->slot('id', null, []); ?> 
                                    payment-detail-<?php echo e($data->id); ?>

                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('title', null, []); ?> 
                                    Payment Detail
                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('content', null, []); ?> 
                                    <div class="px-4 py-2 bg-white rounded-md mb-2 shadow-sm border border-gray-200">
                                        <p class="text-sm text-gray-600 italic">ID : <?php echo e($data->payment->transaction_id?? 'N/A'); ?></p>
                                        <p class="text-sm text-gray-600 italic"><?php echo e(optional($data->payment)->created_at ? $data->payment->created_at->format('Y-m-d H:i:s') : 'N/A'); ?></p>
                                        <p class="text-sm text-gray-600 font-semibold">Status: <?php echo e($data->payment->transaction_status ?? 'N/A'); ?></p>
                                        <p class="text-sm text-gray-600 italic">Payment Type: <?php echo e($data->payment->payment_type ?? 'N/A'); ?></p>
                                        <p class="text-sm text-gray-600 italic">Grand Total: Rp <?php echo e($data->payment ? number_format($data->payment->gross_amount, 2) : 'N/A'); ?></p>
                                        <?php if(!empty($data->payment->response_json)): ?>
                                            <p class="text-sm text-gray-600 italic flex items-center">
                                                <i class="ph ph-printer mr-2 text-sm"></i>
                                                <a href="<?php echo e(route('download.response', $data->payment->id)); ?>" 
                                                class="text-blue-500 hover:underline">
                                                Download
                                                </a>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                 <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d)): ?>
<?php $attributes = $__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d; ?>
<?php unset($__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d)): ?>
<?php $component = $__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d; ?>
<?php unset($__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d); ?>
<?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('scripting', null, []); ?> 
                <script>
                    function openModal(id) {
                        document.getElementById(id).classList.remove('hidden');
                    }

                    function closeModal(id) {
                        document.getElementById(id).classList.add('hidden');
                    }
                </script>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $attributes = $__attributesOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__attributesOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $component = $__componentOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__componentOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\project\resources\views/admin/history.blade.php ENDPATH**/ ?>