<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4">
        <h2 class="text-2xl font-bold mb-4">Order History</h2>

        <?php if($datas->isEmpty()): ?>
            <p class="text-gray-600">No order history available.</p>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-300 rounded-lg shadow-md ">
                    <thead>
                    <tr class="bg-gray-200">
                        <th class="py-1 px-4 border">Order Time</th>
                        <th class="py-2 px-4 border">Order Id</th>
                        <th class="py-2 px-4 border">Status  Payment</th>
                        <th class="py-2 px-4 border">Total Amount</th>
                        <th class="py-2 px-4 border">Note</th>
                        <th class="py-2 px-4 border">Detail Order</th>
                        <th class="py-2 px-4 border">Detail Payment</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td class="py-2 px-4 border"><?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d M Y, H:i')); ?></td>
                            <td class="py-2 px-4 border"><?php echo e($order->order_code); ?></td>
                            <td class="py-2 px-4 border relative">
                                <span class="px-2 py-1 rounded
                                    <?php echo e($order->order_status == 'success' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'); ?>">
                                    <?php echo e(ucfirst($order->order_status)); ?>

                                </span>
                            </td>
                            <td class="py-2 px-4 border">Rp <?php echo e(number_format($order->gross_amount, 0, ',', '.')); ?></td>
                            <td class="py-2 px-4 border"><?php echo e($order->note ?? '-'); ?></td>
                            <td class="py-2 px-4 border">
                            <?php if (isset($component)) { $__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pop-up','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pop-up'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                 <?php $__env->slot('id', null, []); ?> 
                                    order-detail-<?php echo e($order->id); ?>

                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('title', null, []); ?> 
                                    Order Detail
                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('content', null, []); ?> 
                                        <?php $__currentLoopData = $order->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="px-4 py-2 bg-white rounded-md mb-2 shadow-sm border border-gray-200">
                                                <p class="text-sm text-gray-800 font-semibold">
                                                    <?php echo e($menuOrder->created_at->format('Y-m-d H:i:s')); ?> -
                                                    <?php echo e($menuOrder->quantity); ?> x <?php echo e($menuOrder->menu->name); ?>

                                                </p>
                                                <p class="text-sm text-gray-500 italic">Price: Rp <?php echo e(number_format($menuOrder->price, 2)); ?></p>
                                                <p class="text-sm text-gray-500 italic">Subtotal: Rp <?php echo e(number_format($menuOrder->subtotal, 2)); ?></p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d)): ?>
<?php $attributes = $__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d; ?>
<?php unset($__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d)): ?>
<?php $component = $__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d; ?>
<?php unset($__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d); ?>
<?php endif; ?>
                            </td>
                            <td class="py-2 px-4 border">
                            <?php if (isset($component)) { $__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pop-up','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pop-up'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                 <?php $__env->slot('id', null, []); ?> 
                                    payment-detail-<?php echo e($order->id); ?>

                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('title', null, []); ?> 
                                    Payment Detail
                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('content', null, []); ?> 
                                        <div class="px-4 py-2 bg-white rounded-md mb-2 shadow-sm border border-gray-200">
                                            <p class="text-sm text-gray-800 font-semibold"><?php echo e(optional($order->payment)->settlement_time ? \Carbon\Carbon::parse($order->payment->settlement_time)->format('Y-m-d H:i:s') : 'N/A'); ?></p>
                                            <p class="text-sm text-gray-500 italic">Payment: <?php echo e($order->payment->payment_type ?? 'N/A'); ?></p>
                                            <p class="text-sm text-gray-500 italic">    Grand Total: Rp <?php echo e(optional($order->payment)->gross_amount ? number_format(optional($order->payment)->gross_amount, 2) : 'N/A'); ?></p>
                                        </div>
                                 <?php $__env->endSlot(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d)): ?>
<?php $attributes = $__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d; ?>
<?php unset($__attributesOriginal7b52e80f422d3615b49e901cb9c9ec4d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d)): ?>
<?php $component = $__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d; ?>
<?php unset($__componentOriginal7b52e80f422d3615b49e901cb9c9ec4d); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    <script>
        function openModal(id) {
            document.getElementById(id).classList.remove('hidden');
        }

        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\project\resources\views/user/history_user.blade.php ENDPATH**/ ?>