<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <div class="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-5 gap-5 justify-center">
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('content', null, []); ?> 
                        <img src="<?php echo e(Storage::url($data->image_path)); ?>" class="w-full h-full object-cover">
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('tittle', null, []); ?> 
                        <div class="flex items-center justify-between mb-2">
                            <p class="block font-sans text-base antialiased font-medium leading-relaxed text-blue-gray-900">
                                <?php echo e($data->name); ?>

                            </p>
                            <?php
                                $discountedPrice = $data->price - $data->discount;
                            ?>
                            <p class="block font-sans text-base antialiased font-medium leading-relaxed text-blue-gray-900">
                                <?php if($data->discount > 0): ?>
                                    <span class="text-red-600 line-through block">Rp <?php echo e(number_format($data->price, 0, ',', '.')); ?></span>
                                    <span class="text-gray-500 font-bold block">Rp <?php echo e(number_format($discountedPrice, 0, ',', '.')); ?></span>
                                <?php else: ?>
                                    Rp <?php echo e(number_format($data->price, 0, ',', '.')); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('description', null, []); ?> 
                        <?php echo e($data->description); ?>

                        <br>
                        <strong>Stock:</strong> <?php echo e($data->stock); ?>

                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('button', null, []); ?> 
                        <div class="flex justify-center items-center space-x-4">
                            <button class="font-sans font-bold text-center py-3 px-6 rounded-lg bg-blue-gray-900 text-white"
                                    type="button"
                                    onclick="toggleStar(this, '<?php echo e($data->id); ?>')">
                                <i class="bi <?php echo e($data->is_favorite ? 'bi-star-fill' : 'bi-star'); ?> text-yellow-500 text-xl"></i>
                            </button>
                            <button class="font-sans font-bold text-center py-3 px-6 rounded-lg bg-blue-gray-900 text-blue-gray-900"
                                    type="button"
                                    onclick="addToCart(event, '<?php echo e($data->id); ?>')">
                                Add to Cart
                            </button>
                        </div>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
    function toggleStar(button, menuId) {
        let starIcon = button.querySelector("i");

        fetch("<?php echo e(route('user.favorite')); ?>", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
            },
            body: JSON.stringify({ menu_id: menuId })
        }).then(response => response.json())
            .then(data => {
                if (data.status === "added") {
                    starIcon.classList.remove("bi-star");
                    starIcon.classList.add("bi-star-fill");
                } else if (data.status === "removed") {
                    starIcon.classList.remove("bi-star-fill");
                    starIcon.classList.add("bi-star");
                } else {
                    console.error("Unexpected response:", data);
                }
            }).catch(error => console.error("Error:", error));
    }
    function addToCart(event, itemId) {
        event.preventDefault();

        fetch("<?php echo e(route('user.add-cart')); ?>", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
            },
            body: JSON.stringify({ id: itemId })
        }).then(response => response.json())
            .then(data => {
                alert(data.message);
            }).catch(error => console.error("Error:", error));
    }
</script>


<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\skripsi\project\resources\views/user/menu_user.blade.php ENDPATH**/ ?>