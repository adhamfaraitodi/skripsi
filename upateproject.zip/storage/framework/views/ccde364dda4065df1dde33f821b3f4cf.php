<?php $__env->startSection('page_title', 'Table Management'); ?>
<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->role_id == 1): ?>
            <div class="mb-6 flex items-center space-x-4">
            <h3 class="text-lg font-semibold text-gray-700">Put Total Table:</h3>
            <form action="<?php echo e(route('table.create')); ?>" method="POST" class="flex items-center">
                <?php echo csrf_field(); ?>
                <input type="number" name="total" min="1" required
                       class="border rounded-md px-2 py-1 w-20 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <button type="submit" class="ml-2 text-green-600 hover:text-green-900">
                    <i class="ph ph-arrows-clockwise text-3xl"></i>
                </button>
            </form>
        </div>
            <?php endif; ?>
        <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal69ce08111976df7a79cd416995514cd4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69ce08111976df7a79cd416995514cd4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table-data','data' => ['name' => 'Table Management']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Table Management')]); ?>
         <?php $__env->slot('column', null, []); ?> 
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No.</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Table Number</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Table Code</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Table qr code</th>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('row', null, []); ?> 
            <?php $__empty_1 = true; $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900"><?php echo e($loop->iteration); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center">
                            <div class="w-48 text-sm font-medium text-gray-900"><?php echo e($data->number); ?></div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900"><?php echo e($data->table_code); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div id="qrcode-<?php echo e($data->table_code); ?>"></div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('scripting', null, []); ?> 
            <script>
                document.addEventListener("DOMContentLoaded", function () {
                    let tables = <?php echo json_encode($datas, 15, 512) ?>;
                    tables.forEach(function (data) {
                        let elementId = "qrcode-" + data.table_code;
                        let url = "<?php echo e(url('/scan')); ?>/" + data.table_code;

                        new QRCode(document.getElementById(elementId), {
                            text: url,
                            width: 100,
                            height: 100
                        });
                    });
                });
            </script>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $attributes = $__attributesOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__attributesOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69ce08111976df7a79cd416995514cd4)): ?>
<?php $component = $__componentOriginal69ce08111976df7a79cd416995514cd4; ?>
<?php unset($__componentOriginal69ce08111976df7a79cd416995514cd4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\skripsi\project\resources\views/admin/table.blade.php ENDPATH**/ ?>